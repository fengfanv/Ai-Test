# coding: utf-8

GPU = False
